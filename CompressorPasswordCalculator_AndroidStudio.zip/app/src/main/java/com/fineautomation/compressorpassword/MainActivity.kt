package com.fineautomation.compressorpassword

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PasswordCalculatorScreen() }
    }
}

@Composable
fun PasswordCalculatorScreen() {
    var hint by remember { mutableStateOf("") }
    var password by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    MaterialTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "COMPRESSOR PASSWORD",
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "أدخل Hint Code المكوّن من 4 أرقام",
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(22.dp))

                OutlinedTextField(
                    value = hint,
                    onValueChange = {
                        hint = it.filter(Char::isDigit).take(4)
                        password = null
                        error = null
                    },
                    label = { Text("Hint Code") },
                    placeholder = { Text("مثال: 1234") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = {
                        if (hint.length != 4) {
                            error = "أدخل 4 أرقام كاملة"
                            password = null
                        } else {
                            val a = hint[0].digitToInt()
                            val b = hint[1].digitToInt()
                            val c = hint[2].digitToInt()
                            val d = hint[3].digitToInt()

                            // Rule confirmed by the user:
                            // ones digit of A*2; tens digit of B+6;
                            // ones digit of C*8; tens digit of D+8.
                            val p1 = (a * 2) % 10
                            val p2 = (b + 6) / 10
                            val p3 = (c * 8) % 10
                            val p4 = (d + 8) / 10

                            password = "$p1$p2$p3$p4"
                            error = null
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("احسب الباسويرد")
                }

                error?.let {
                    Spacer(Modifier.height(12.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }

                password?.let {
                    Spacer(Modifier.height(24.dp))
                    Text("الباسويرد", fontSize = 18.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = it,
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 8.sp
                    )
                }

                Spacer(Modifier.height(32.dp))
                Text(
                    text = "أداة حساب محلية — لا تحتاج إلى إنترنت",
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
